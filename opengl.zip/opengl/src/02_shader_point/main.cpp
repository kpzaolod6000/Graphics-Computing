//#include <GL/glew.h>
#include <glad/glad.h>
#include <glfw/glfw3.h>

#include <iostream>

using namespace std;


#define numVAOs 1
GLuint renderingProgram;
GLuint vao[numVAOs];

GLuint createShaderProgram() {
	const char *vshaderSource =
			"#version 430 \n"
			"void main(void) \n"
			"{ gl_Position = vec4(0.0, 0.0, 0.0, 1.0); }";
	// creamos un vertice, no especificamos salida, porque gl_position es por defecto de salida
	const char *fshaderSource =
			"#version 430 \n"
			"out vec4 color; \n"
			"void main(void) \n"
			"{ color = vec4(0.0, 0.0, 1.0, 1.0); }";
	//en el etapss entre vertex y fragment, el vertice se convierte en un pixel
	//especificamos el color de los pixeles

	GLuint vShader = glCreateShader(GL_VERTEX_SHADER);
	GLuint fShader = glCreateShader(GL_FRAGMENT_SHADER);

	glShaderSource(vShader, 1, &vshaderSource, NULL);
	glShaderSource(fShader, 1, &fshaderSource, NULL);
	glCompileShader(vShader);
	glCompileShader(fShader);
	GLuint vfProgram = glCreateProgram();
	glAttachShader(vfProgram, vShader);
	glAttachShader(vfProgram, fShader);
	glLinkProgram(vfProgram);
	return vfProgram;
}

void init(GLFWwindow* window) {
	renderingProgram = createShaderProgram();
	glGenVertexArrays(numVAOs, vao);
	glBindVertexArray(vao[0]);
}

void display(GLFWwindow* window, double currentTime) {
	glUseProgram(renderingProgram);
	glPointSize(30.0f); // un vertice es un pixel, con esto especificamos el tamaño del pixel
	glDrawArrays(GL_POINTS, 0, 1);

}

int main(void) {
	if (!glfwInit()) { exit(EXIT_FAILURE); }
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	GLFWwindow* window = glfwCreateWindow(600, 600, "Chapter2 - program1", NULL, NULL);
	glfwMakeContextCurrent(window);

	//if (glewInit() != GLEW_OK) { exit(EXIT_FAILURE); }
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)){ exit(EXIT_FAILURE); }

	glfwSwapInterval(1);
	init(window);
	while (!glfwWindowShouldClose(window)) {
			display(window, glfwGetTime());
			glfwSwapBuffers(window);
			glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate();
	exit(EXIT_SUCCESS);

}